﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms; // importa lib

namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e) 
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int numero1) && int.TryParse(textBox2.Text, out int numero2))
            {
                int soma = numero1 + numero2;

                textBox3.Text = ("" + soma);
            }
            else
            {
                textBox3.Text = "Erro. digite um numero.";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int numero3) && int.TryParse(textBox2.Text, out int numero4))
            {
                int sub = numero3 - numero4;

                textBox3.Text = ("" + sub);
            }
            else
            {
                textBox3.Text = "Erro. digite um numero.";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int numero5) && int.TryParse(textBox2.Text, out int numero6))
            {
                int mult = numero5 * numero6;

                textBox3.Text = textBox3.Text = ("" + mult);
            }
            else
            {
                textBox3.Text = "Erro. digite um numero.";
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int numero7) && int.TryParse(textBox2.Text, out int numero8))
            {
                int div = numero7 / numero8;

                textBox3.Text = textBox3.Text = ("" + div);
            }
            else
            {
                textBox3.Text = "Erro. digite um numero.";
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Text = "Calculadora Basica em C Sharp com Windows Forms";
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Text = "Info";
            MessageBox.Show("Algoritmo: Calculadora Basica em C Sharp com Windows Forms\n" + "\nAuthor: PHNO" + "\nData Release: 13/04/2024" + "\nVersao Codigo: 1.0.0v" + "\nReplit: @PHNO, @PHREPLIT" + "\nEmail: phreplit@gmail.com");

        }

    }
}
